'use strict';


var demoFrontend = angular.module('demoFrontend', []);


demoFrontend.controller('demoCtrl', function demoCtrl($scope, $http) {
    //http get function
    $http.get("http://localhost:8080/accounts").then(function (response){

        $scope.accounts = response.data;

    });

    //http post function
    $scope.firstName = null;
    $scope.lastName = null;
    $scope.id = null;
    $scope.postdata = function(firstName, lastName, id){
        var data = {
            firstName: firstName,
            lastName: lastName,
            id: id

        };


        $http.post("http://localhost:8080/accounts", JSON.stringify(data)).then (function (response){
            if (response.data)
                $scope.msg = "Post Data Submitted Successfully!";

        }, function (response) {
            $scope.msg = JSON.stringify(data)
            $scope.statusval = response.status;
            $scope.statustext = response.statusText;
            $scope.headers = response.xhrStatus;


        })

    }
});