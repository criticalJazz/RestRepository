package com.example.demo.repository;


import com.example.demo.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountRepository extends JpaRepository<Account, String> {

    List<Account> findByLastName(String lastName);

    @Override
    <S extends Account> S save(S s);

    List<Account> findAll();
}
