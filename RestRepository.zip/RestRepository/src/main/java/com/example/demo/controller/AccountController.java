package com.example.demo.controller;

import com.example.demo.model.Account;
import com.example.demo.service.AccountService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
//@CrossOrigin(origins = "http://localhost:8000")
//@RequestMapping("/accounts")
public class AccountController {

    private AccountService accountService;

    public AccountController(AccountService accountService)
    {
        this.accountService = accountService;
    }

    @RequestMapping(value = "accounts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Account> getAllAccounts(){
        return accountService.getAllAccounts();

    }

    @RequestMapping(value = "accounts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void createAccount(@RequestBody Account account)
    {
        accountService.save(account);
    }





}
